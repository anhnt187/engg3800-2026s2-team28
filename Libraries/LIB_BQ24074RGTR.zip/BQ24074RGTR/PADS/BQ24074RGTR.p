*PADS-LIBRARY-PART-TYPES-V9*

BQ24074RGTR QFN50P300X300X100-17N-D I ANA 7 1 0 0 0
TIMESTAMP 2026.08.05.08.03.39
"Mouser Part Number" 595-BQ24074RGTR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/BQ24074RGTR?qs=ZV%2Fxhq4oszp2Nll7fIx5wg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" BQ24074RGTR
"Description" USB-Friendly Li-Ion Battery Charger and Power-Path Management IC, 10.5V OVP
"Datasheet Link" http://www.ti.com/lit/ds/symlink/bq24074.pdf
"Geometry.Height" 1mm
GATE 1 17 0
BQ24074RGTR
1 0 U TS
2 0 U BAT_1
3 0 U BAT_2
4 0 U \CE
5 0 U EN2
6 0 U EN1
7 0 U \PGOOD
8 0 U VSS
12 0 U ILIM
11 0 U OUT_2
10 0 U OUT_1
9 0 U \CHG
17 0 U GND
16 0 U ISET
15 0 U TD
14 0 U TMR
13 0 U IN

*END*
*REMARK* SamacSys ECAD Model
632482/2072920/2.50/17/3/Integrated Circuit
